import React,{useEffect,useState} from "react";
import HeroBanner from "../components/HeroBanner";
import AnimeRow from "../components/AnimeRow";
import {sections,fetchAnimeByCategory} from "../api/anilist";

export default function Home(){
  const [data,setData]=useState({});
  const [activeRow,setActiveRow]=useState(0);
  const [activeCard,setActiveCard]=useState(0);

  useEffect(()=>{
    async function load(){
      const res={};
      for(const s of sections){
        res[s.key]=await fetchAnimeByCategory(s.key);
      }
      setData(res);
    }
    load();
  },[]);

  const hero=data[sections[0]?.key]?.[activeCard];

  return (
    <div style={{background:'black',color:'white'}}>
      <HeroBanner anime={hero}/>
      {sections.map((s,i)=>(
        <AnimeRow key={s.key} title={s.title} items={data[s.key]||[]} rowIndex={i} activeRow={activeRow} activeCard={activeCard}/>
      ))}
    </div>
  )
}
