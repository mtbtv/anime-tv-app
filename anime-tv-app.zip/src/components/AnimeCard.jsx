import React from "react";
import { Play } from "lucide-react";
import { formatRating } from "../utils/helpers";

export default function AnimeCard({anime, active}){
  return (
    <div className={`min-w-[240px] h-[340px] rounded-2xl overflow-hidden border-4 transition-all ${
      active ? "border-cyan-400 scale-110" : "border-transparent opacity-80"
    }`}>
      <img src={anime.coverImage.extraLarge} className="w-full h-full object-cover" />
      <div className="absolute bottom-0 p-4">
        <h3>{anime.title.english || anime.title.romaji}</h3>
        <span>⭐ {formatRating(anime.averageScore)}</span>
      </div>
    </div>
  )
}
