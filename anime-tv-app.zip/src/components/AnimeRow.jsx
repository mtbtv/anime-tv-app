import React, {useRef,useEffect} from "react";
import AnimeCard from "./AnimeCard";

export default function AnimeRow({title,items,activeRow,rowIndex,activeCard}){
  const ref = useRef();
  useEffect(()=>{
    if(activeRow===rowIndex){
      ref.current?.scrollTo({left:activeCard*260,behavior:'smooth'});
    }
  },[activeCard,activeRow]);

  return (
    <div>
      <h2>{title}</h2>
      <div ref={ref} className="flex overflow-x-hidden gap-4">
        {items.map((a,i)=>(
          <AnimeCard key={a.id} anime={a} active={i===activeCard && activeRow===rowIndex}/>
        ))}
      </div>
    </div>
  )
}
