import React from "react";
import { formatRating, cleanDescription } from "../utils/helpers";

export default function HeroBanner({anime}){
  if(!anime) return null;
  return (
    <div className="h-[70vh] relative">
      <img src={anime.bannerImage || anime.coverImage.extraLarge} className="w-full h-full object-cover opacity-40"/>
      <div className="absolute bottom-10 left-10">
        <h1>{anime.title.english || anime.title.romaji}</h1>
        <p>{cleanDescription(anime.description)}</p>
        <span>⭐ {formatRating(anime.averageScore)}</span>
      </div>
    </div>
  )
}
